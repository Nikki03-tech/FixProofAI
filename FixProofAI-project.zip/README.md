# FixProof AI 🛠️

An AI debugging assistant for Python and JavaScript, built for BharatCode Build League.

## Features
- Explains likely root causes in beginner-friendly language
- Proposes corrected code and explains why the change helps
- Generates test cases and a verification plan
- Adjustable explanation depth
- Downloadable Markdown debugging report
- Light, responsive Streamlit interface
- Server-side API key configuration
- Does **not** execute untrusted user code or pretend tests were run

## Run locally
Requires Python 3.10+.

```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
export BHARATCODE_API_KEY="your-key"
streamlit run app.py
```

On Windows PowerShell, set the environment variable with:
```powershell
$env:BHARATCODE_API_KEY="your-key"
streamlit run app.py
```

Alternatively, for Streamlit Community Cloud, add `BHARATCODE_API_KEY` under **App settings → Secrets**. Do not commit a real key to GitHub.

## BharatCode API
The app uses the OpenAI-compatible endpoint `https://bharatcode.ai/api/model/v1` and model `qwen-3.8-27b`. Confirm model availability and API access in your BharatCode account.

## Safety notes
Submitted code and error text are sent to BharatCode only after the user presses Analyse. Do not submit secrets, credentials, or confidential production code. The app does not execute user code. AI suggestions should be reviewed and tested before being applied.

## Hackathon
See `BharatCode.txt` for the project description submitted for BharatCode Build League.
